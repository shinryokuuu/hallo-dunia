<?php
/**
* @package com_splms
* @author JoomShaper http://www.joomshaper.com
* @copyright Copyright (c) 2010 - 2018 JoomShaper
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
*/

// No Direct Access
defined ('_JEXEC') or die('Resticted Aceess');

$helix_path = JPATH_PLUGINS . '/system/helixultimate/core/helixultimate.php';
if (file_exists($helix_path)) {
    require_once($helix_path);
    $theme = new helixUltimate;
} else {
    die('Install and activate <a target="_blank" href="https://www.joomshaper.com/helix">Helix Ultimate Framework</a>.');
}

$input = JFactory::getApplication()->input;
$Itemid = $input->get('Itemid', 0, 'INT');
$monthindex = $input->get('monthindex', NULL, 'INT');
$event_type = $input->get('etype', NULL, 'WORD');

$etype_include = '';
if($event_type) {
	$etype_include = '&etype=' . $event_type;
}

if($event_type) {
	$month_url = 'index.php?option=com_splms&view=events&monthindex='. $monthindex . $etype_include . '&Itemid=' . $Itemid;
} else {
	$month_url = 'index.php?option=com_splms&view=events&monthindex='. $monthindex . '&Itemid=' . $Itemid;
}

$month_include = '';
if($monthindex) {
	$month_include = '&monthindex=' . $monthindex;
}

//event type url
//$all_event_url 		= 'index.php?option=com_splms&view=events'. $month_include .'&etype=all&Itemid=' . $Itemid;
$all_event_url 		= 'index.php?option=com_splms&view=events&etype=all&Itemid=' . $Itemid;
$latest_event_url 	= 'index.php?option=com_splms&view=events'. $month_include .'&etype=latest&Itemid=' . $Itemid;
$upcoming_event_url = 'index.php?option=com_splms&view=events'. $month_include .'&etype=upcoming&Itemid=' . $Itemid;

// include countdown js file
$theme->add_js('jquery.countdown.min.js');
$ordering 	= $this->params->get('ordering', ' DESC');

?>

<div id="splms" class="splms splms-view-events">
	<?php if(count((array)$this->model->getAllEvents()) && !empty($this->model->getAllEvents()) && $featured_event =  $this->model->getAllEvents()[0]) { ?>
		<?php
			$speakers = $this->model->getEventSpeakers($featured_event->speaker_id);
			$event_end_date = str_replace('-', '/' ,$featured_event->event_end_date);
		?>
		<div class="splms-events-countdown-item">
			<div class="splms-row">
				<div class="splms-col-sm-6">
					<img src="<?php echo $featured_event->thumb; ?>" alt="">
				</div>
				<div class="splms-col-sm-6">
					<div id="splms-featured-event-countdown"></div>
					<script type="text/javascript">
					let eventEndDate = <?php echo json_encode($event_end_date); ?>;
						jQuery(function($) {
							$('#splms-featured-event-countdown').countdown(eventEndDate, function(event) {
								$(this).html(event.strftime('<div class="splms-fevent-countdown-days"><span class="splms-fevent-countdown-number">%-D</span><span class="splms-fevent-countdown-string">%!D:<?php echo JText::_("HELIX_ULTIMATE_DAY"); ?>,<?php echo JText::_("HELIX_ULTIMATE_DAYS"); ?>;</span></div><div class="splms-fevent-countdown-hours"><span class="splms-fevent-countdown-number">%H</span><span class="splms-fevent-countdown-string">%!H:<?php echo JText::_("HELIX_ULTIMATE_HOUR"); ?>,<?php echo JText::_("HELIX_ULTIMATE_HOURS"); ?>;</span></div><div class="splms-fevent-countdown-minutes"><span class="splms-fevent-countdown-number">%M</span><span class="splms-fevent-countdown-string">%!M:<?php echo JText::_("HELIX_ULTIMATE_MINUTE"); ?>,<?php echo JText::_("HELIX_ULTIMATE_MINUTES"); ?>;</span></div><div class="splms-fevent-countdown-seconds"><span class="splms-fevent-countdown-number">%S</span><span class="splms-fevent-countdown-string">%!S:<?php echo JText::_("HELIX_ULTIMATE_SECOND"); ?>,<?php echo JText::_("HELIX_ULTIMATE_SECONDS"); ?>;</span></div>'));
							});
						
						});
					</script>
					
					<h3><?php echo $featured_event->title; ?></h3>
					<div class="splms-countdown-event-info">
						<?php if(isset($speakers) && !empty($speakers)) { ?>
							<?php foreach ($speakers as $speaker) { ?>
								<div class="splms-countdown-event-info-left">
									<p><?php echo JText::_('COM_SPLMS_EVENT_SPEAKER') . ': '; ?></p>
									<p>
										<span><?php echo $speaker->designation; ?></span>
										<?php echo $speaker->title; ?>
									</p>
								</div>
							<?php } ?>
						<?php } ?>

						<div class="splms-countdown-event-info-right">
							<p><?php echo JText::_('COM_SPLMS_EVENT_DATE_TIME') . ': '; ?></p>
							<p class="event-adress">
								<?php echo $featured_event->event_start_date; ?>
								<span>
									<?php echo $featured_event->event_time; ?>
									<?php echo $featured_event->event_end_date; ?>
								</span>
							</p>
							<p class="event-time">
								<?php echo $featured_event->event_address; ?>
							</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	<?php }?>

	<div class="splms-events-filters">
		<div class="splms-event-sorting-etype">
			<ul class="list-inline list-style-none">
				<li class="<?php echo (( ($ordering != 'upcoming' && $ordering != 'latest') && !$event_type) || $event_type == 'all') ? 'active': '';?>">
					<a href="<?php echo JRoute::_($all_event_url);?>"><?php echo JText::_('COM_SPLMS_EVENTS_ALL'); ?></a>
				</li>
				<li class="<?php echo ( ($ordering == 'upcoming' && !$event_type) || $event_type == 'upcoming') ? 'active': '';?>">
					<a href="<?php echo JRoute::_($upcoming_event_url);?>"><?php echo JText::_('COM_SPLMS_EVENTS_UPCOMING'); ?></a>
				</li>
				<li class="<?php echo ( ($ordering == 'latest' && !$event_type ) || $event_type == 'latest') ? 'active': '';?>">
					<a href="<?php echo JRoute::_($latest_event_url);?>"><?php echo JText::_('COM_SPLMS_EVENTS_LATEST'); ?></a>
				</li>
			</ul>
		</div>

		<div class="splms-event-sorting-month">
			<ul class="list-inline list-style-none">
				<?php foreach ($this->months as $month) {?>
				<li class="<?php echo ($monthindex == $month) ? 'active': '';?>">
					<a href="<?php echo JRoute::_($month_url . '&monthindex='.$month);?>">
						<?php echo date("F", mktime(0, 0, 0, $month, 10)); ?>
					</a>
				</li>
				<?php } ?>
			</ul>
		</div>
	</div>

	<?php if(count($this->items)) { ?>
	<?php foreach ($this->items as $event) { ?>
		<div class="splms-event splms-col-sm-6">
			<div class="splms-event-details">
				<div class="splms-event-info-list">
					<div class="splms-upcoming-event-date">
						<?php echo JHtml::_('date', $event->event_start_date, 'M'); ?>
						<span class="splms-upcoming-event-date-day">
							<?php echo JHtml::_('date', $event->event_start_date, 'd'); ?>
						</span>
					</div>
					<div class="splms-upcoming-event-time-wrap">
						<span class="splms-upcoming-event-time">
							<?php echo JHtml::_('date', $event->event_time, 'g:i a'); ?> - 
							<?php echo JHtml::_('date', $event->event_end_time, 'g:i a'); ?>
						</span>
						<span class="splms-upcoming-event-address">
							<?php echo $event->event_address;?>
						</span>
					</div>
				</div>

				<h3 class="splms-event-title">
					<a href="<?php echo $event->url; ?>">
						<?php echo $event->title; ?>
					</a>
				</h3>

				<?php if ($this->params->get('show_readmore')) { ?>
				<?php } ?>
			</div>
		</div>

	<?php } ?>

	<?php if ($this->params->get('hide_pagination') == 0) { ?>
		<?php if ($this->pagination->get('pages.total') >1) { ?>
		<div class="pagination">
			<?php echo $this->pagination->getPagesLinks(); ?>
		</div>
		<?php } ?>
	<?php }?>

	<?php } ?>
</div>