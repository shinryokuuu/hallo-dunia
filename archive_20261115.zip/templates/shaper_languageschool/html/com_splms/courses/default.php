<?php
/**
* @package com_splms
* @author JoomShaper http://www.joomshaper.com
* @copyright Copyright (c) 2010 - 2018 JoomShaper
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
*/

// No Direct Access
defined ('_JEXEC') or die('Resticted Aceess');

$doc = JFactory::getDocument();
$features_course = $doc->countModules('splms-features-courses');

?>

<div id="splms" class="splms view-splms-courses">
	<?php if($features_course){ ?>
		<div class="splms-features-courses">
			<?php
				jimport('joomla.application.module.helper');
				$modules = JModuleHelper::getModules('splms-features-courses');
				$attribs['style'] = 'sp_xhtml';

				foreach ($modules as $key => $module) {
						echo JModuleHelper::renderModule($module, $attribs);
				}
			?>
		</div>
	<?php } ?>

	<?php if(count($this->items)) { ?>
	<div class="splms-courses-list">

	<?php foreach(array_chunk($this->items, $this->columns) as $this->items) { ?>
		<div class="splms-row">

		<?php foreach ($this->items as $key=>$course) {
			$discount_percentage = '';
			if( ($course->price > $course->sale_price) && ($course->sale_price != '0.00' && $course->price != '0.00') ) {
				$discount_percentage = (($course->price - $course->sale_price)*100) /$course->price;
			} ?>
			<div class="splms-col-sm-<?php echo round(12/$this->columns); ?>">
				<div class="splms-course">
					<div class="splms-common-overlay-wrapper">

							<img src="<?php echo $course->thumb; ?>" class="splms-course-img splms-img-responsive" alt="<?php echo $course->title; ?>">

							<?php if ($course->price == 0) {
								echo '<span class="splms-badge-free">' . JText::_('COM_SPLMS_FREE') . '</span>';
							} ?>
							<a href="<?php echo $course->url; ?>" class="splms-courses-read-more"></a>
							<?php if (isset($discount_percentage) && $discount_percentage) {?>
								<span class="splms-course-discount-price"><?php echo round($discount_percentage) . JText::_('MOD_SPLMS_COURSES_PERCENT_OFF'); ?></span>
							<?php }?>
					</div>

					<div class="splms-course-info">
						<h3 class="splms-courses-title">
							<a href="<?php echo $course->url; ?>">
								<?php echo $course->title; ?>
							</a>
						</h3>
						<div class="splms-course-time"><?php echo $course->course_time; ?></div>
						
						<p class="splms-course-short-info"><?php echo $course->short_description; ?></p>
						<p class="splms-course-duration"><?php echo $course->duration; ?></p>
						<p class="splms-course-deadline"><?php echo $course->level; ?></p>
						
						<div class="splms-course-meta">
							<ul>
								<li><?php echo $course->course_price; ?></li>
								<!-- <li><?php echo count($course->lessons); ?> <?php echo JText::_('COM_SPLMS_COMMON_LESSONS'); ?></li>
								<li><?php echo count($course->total_attachments); ?> <?php echo JText::_('COM_SPLMS_COMMON_ATTACHMENTS'); ?></li> -->
							</ul>
						</div>
					</div> <!-- /.splms-course-info -->
				</div> <!-- /.splms-course -->
			</div> <!-- /.splms-col-sm -->
		<?php } // END:: foreach ?>

	</div> <!-- /.splms-row -->
	<?php } // END::array_chunk ?>

	</div> <!-- /.splms-courses-list -->
	<?php } // END::has items ?>

	<?php if ($this->params->get('hide_pagination') == 0) { //Pagination ?>
		<?php if ($this->pagination->get('pages.total') >1) { ?>
			<div class="pagination">
				<?php echo $this->pagination->getPagesLinks(); ?>
			</div>
		<?php } ?>
	<?php } ?>
	
</div>