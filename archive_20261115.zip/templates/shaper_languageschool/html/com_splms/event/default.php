<?php
/**
* @package com_splms
* @author JoomShaper http://www.joomshaper.com
* @copyright Copyright (c) 2010 - 2018 JoomShaper
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
*/

// No Direct Access
defined ('_JEXEC') or die('Resticted Aceess');

// Event date load
$doc = JFactory::getDocument();
$doc->addStylesheet(JURI::root(true) . '/components/com_splms/assets/css/lightboxgallery-min.css');
$doc->addScript(JURI::root(true) . '/components/com_splms/assets/js/lightboxgallery-min.js');

$helix_path = JPATH_PLUGINS . '/system/helixultimate/core/helixultimate.php';
if (file_exists($helix_path)) {
    require_once($helix_path);
    $theme = new helixUltimate;
} else {
    die('Install and activate <a target="_blank" href="https://www.joomshaper.com/helix">Helix Ultimate Framework</a>.');
}

// include countdown js file
$theme->add_js('jquery.countdown.min.js');
$today_raw_today = JFactory::getDate()->format('Y-m-d');
// $event_raw_date = JHtml::date($this->item->event_start_date, 'Y-m-d');
$this->item->event_start_date = JHtml::date($this->item->event_start_date , 'Y-m-d');

?>

<div id="splms" class="splms splms-view-event">

	<div class="splms-events-countdown-item">
		<div class="splms-row">
			<div class="splms-col-sm-6">
				<div class="splms-event-image">
					<img src="<?php echo $this->item->image ?>" class="splms-event-img splms-img-responsive" alt="<?php echo $this->item->title; ?>">
				</div>
			</div>
			<div class="splms-col-sm-6">
				<?php if($today_raw_today < $event_raw_date) { ?>
				<div class="splms-event-countdown-wrap">
					<?php
						$date_explode = explode('-', JHtml::date($this->item->event_start_date, 'd-m-Y'));
						$event_end_date = str_replace('-', '/' ,$this->item->event_end_date);
			
					?>
						<div id="splms-featured-event-countdown"></div>
						<script type="text/javascript">
						let eventEndDate = <?php echo json_encode($event_end_date); ?>;
							jQuery(function($) {
								$('#splms-featured-event-countdown').countdown(eventEndDate, function(event) {
									$(this).html(event.strftime('<div class="splms-fevent-countdown-days"><span class="splms-fevent-countdown-number">%-D</span><span class="splms-fevent-countdown-string">%!D:<?php echo JText::_("HELIX_ULTIMATE_DAY"); ?>,<?php echo JText::_("HELIX_ULTIMATE_DAYS"); ?>;</span></div><div class="splms-fevent-countdown-hours"><span class="splms-fevent-countdown-number">%H</span><span class="splms-fevent-countdown-string">%!H:<?php echo JText::_("HELIX_ULTIMATE_HOUR"); ?>,<?php echo JText::_("HELIX_ULTIMATE_HOURS"); ?>;</span></div><div class="splms-fevent-countdown-minutes"><span class="splms-fevent-countdown-number">%M</span><span class="splms-fevent-countdown-string">%!M:<?php echo JText::_("HELIX_ULTIMATE_MINUTE"); ?>,<?php echo JText::_("HELIX_ULTIMATE_MINUTES"); ?>;</span></div><div class="splms-fevent-countdown-seconds"><span class="splms-fevent-countdown-number">%S</span><span class="splms-fevent-countdown-string">%!S:<?php echo JText::_("HELIX_ULTIMATE_SECOND"); ?>,<?php echo JText::_("HELIX_ULTIMATE_SECONDS"); ?>;</span></div>'));
								});
						});
					</script>
					</div> <!-- /.splms-event-countdown-wrap -->
				<?php } else { ?>
					<div id="splms-featured-event-countdown" class="event-over"><?php echo JText::_('COM_SPLMS_THIS_EVENT_IS_OVER'); ?></div>
				<?php } ?>

				<h3><?php echo $this->item->title; ?></h3>
				<div class="splms-countdown-event-info">
					<div class="splms-countdown-event-info-left">
						<p><?php echo JText::_('COM_SPLMS_EVENT_SPEAKER') . ': '; ?></p>
						<?php if(isset($this->item->speaker_infos) && $this->item->speaker_infos && count($this->item->speaker_infos)) {?>
							<div class="splms-event-speakers">
								<?php
								$last_item = end($this->item->speaker_infos);
								foreach ($this->item->speaker_infos as $speaker_info) {
									?>
									<a href="<?php echo $speaker_info->url ?>"><?php echo $speaker_info->title; ?></a>
									<p class="designation"><?php echo $speaker_info->designation; ?></p>
								<?php } ?>
							</div>
						<?php } // has speaker ?>
					</div>
					<div class="splms-countdown-event-info-right">
						<p><?php echo JText::_('COM_SPLMS_EVENT_DATE_TIME') . ': '; ?></p>
						<?php if($this->item->event_address && $this->item->event_end_date) { ?>
							<p class="event-adress">
								<?php echo JHtml::date($this->item->event_start_date , 'DATE_FORMAT_LC3'); ?> - <?php echo JHtml::date($this->item->event_end_date , 'DATE_FORMAT_LC3'); ?>
							</p>
						<?php } // has event start and end date ?>
						<?php if($this->item->event_address) { ?>
							<p class="event-time">
								<?php echo $this->item->event_address; ?>
							</p>
						<?php } // has address ?>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<div class="splms-events-countdown-item-info">
	<div class="row">
		<div class="col-sm-8">
			<!-- event gallery -->
			<?php if (isset($this->item->gallery) && is_array($this->item->gallery) && count($this->item->gallery)) { ?>
				<div class="splms-event-gallery">
					<h3 class="splms-event-title"><?php echo JText::_('COM_SPLMS_EVENT_PHOTO_GALLERY'); ?></h3>
					<div class="splms-event-gallery-list">
						<?php foreach ($this->item->gallery as $key => $gallery_item) { ?>
							<a class="lightboxgallery-gallery-item" href="<?php echo JURI::root() . $gallery_item['image']; ?>">
								<img src="<?php echo JURI::root() . $gallery_item['image']; ?>" alt="image">
								<h4 class="title"><?php echo $gallery_item['text']; ?></h4>
							</a>
						<?php } ?>
					</div> <!-- //.gallery-list -->
				</div> <!-- //.splms-event-gallery -->
			<?php } ?>

			<!-- event topics -->
			<?php if( isset($this->topics) && is_array($this->topics) && count($this->topics) ){ ?>
				<div class="splms-event-topics">
					<h3 class="splms-event-title"><?php echo JText::_('COM_SPLMS_EVENT_TOPICS'); ?></h3>
					<ul class="splms-event-topics-list">
						<?php foreach ($this->topics as $key => $topics) { ?>
							<li>
								<div class="table-responsive">
									<table class="table">
										<thead>
											<tr>
												<td><?php echo $key; ?></td>
											</tr>
										</thead>
										<tbody>
											<?php foreach ($topics as $topic) { ?>
												<tr>
													<?php if($topic['title']) { ?>
													<td><?php echo $topic['title']; ?></td>
													<?php } if($topic['time']) { ?>
													<td><i class="fa fa-clock-o"></i><?php echo $topic['time']; ?></td>
													<?php } if($topic['speaker_infos']) { ?>
													<td><span class="with"><?php echo JText::_('COM_SPLMS_COMMON_WITH'); ?></span> : <a href="<?php echo $topic['speaker_infos']->url; ?>"><?php echo $topic['speaker_infos']->title; ?></a></td>
													<?php } ?>
												</tr> <!-- //each row -->
											<?php } ?>
										</tbody>
									</table>
								</div>
						<?php } ?>
					</ul> <!-- //.splms-event-topics-list -->
				</div> <!-- //.splms-event-topics -->
			<?php } ?>

			<!-- event tickets -->
			<?php if( isset($this->item->pricing_tables) && is_array($this->item->pricing_tables) && count($this->item->pricing_tables) ){ ?>
				<div id="splms-event-tickets" class="splms-event-tickets">
					<h3 class="splms-event-title"><?php echo JText::_('COM_SPLMS_EVENT_TICKETS'); ?></h3>
					<div class="splms-row splms-event-tickets-list">
						<?php foreach ($this->item->pricing_tables as $pricing_table) { ?>
							<div class="splms-col-sm-4">
								<div class="event-pricing-table splms-text-center">
									<div class="splms-pricing-box">
										<div class="splms-pricing-header">
											<span class="splms-pricing-price"><?php echo $pricing_table['price'] ?></span>
											<div class="splms-pricing-title">
												<?php echo $pricing_table['title'] ?>
											</div>
										</div>
										<?php if($pricing_table['description']){ ?>
											<div class="splms-pricing-features">
												<ul>
													<?php 
													$features = explode("\n", $pricing_table['description']);
													foreach ($features as $feature) { ?>
														<li><?php echo $feature; ?></li>
													<?php } ?>
												</ul>
											</div>
										<?php } ?>
										<div class="splms-pricing-footer">
											<?php if($pricing_table['purchase_url']){ ?>
												<a class="splms-btn splms-btn-info splms-btn-rounded" href="#">Proceed <i class="fa fa-chevron-right"></i></a>
											<?php } ?>
										</div>
									</div>
								</div> <!-- //.event-pricing-table -->
							</div> <!-- //.splms-col-sm-4 -->
						<?php } ?>
					</div> <!-- //.splms-row splms-event-tickets-list -->
				</div> <!-- //.splms-event-tickets -->
			<?php } ?>

			<h3 class="splms-event-location-title"><?php echo JText::_('COM_SPLMS_EVENT_DESCRIPTION'); ?></h3>
			<div class="splms-event-description">
				<?php echo $this->item->description; ?>
			</div>
			<ul class="splms-event-detail-list">
				<?php if($this->item->price) {?>
					<li>
						<strong><?php echo JText::_('COM_SPLMS_EVENT_PRICE'). ': '; ?></strong>
						<?php echo $this->item->price; ?>
					</li>
				<?php } ?>
			</ul>
			<?php if($this->item->event_address) { ?>
			<div class="splms-event-location-map">
				<h3 class="splms-event-location-title"><?php echo JText::_('COM_SPLMS_EVENT_LOCATION'); ?></h3>
				<div id="splms-event-map" class="splms-gmap-canvas" data-lat="<?php echo $this->map[0]; ?>" data-lng="<?php echo $this->map[1]; ?>" data-address="<?php echo $this->item->event_address; ?>" style="height:300px"></div>
			</div>
			<?php } ?>


			<div class="splms-event-detail-footer">
				<div class="splms-row">
					<div class="splms-event-purchase-btn splms-col-sm-4">
						<?php if($this->item->buy_url) { ?>
						<a class="btn btn-primary" href="<?php echo $this->item->buy_url; ?>"><?php echo JText::_('COM_SPLMS_EVENT_BUY_TICKET'); ?></a>
						<?php } ?>
					</div>

					<div class="splms-event-shares splms-col-sm-8 text-right">
						<ul>
							<li>
									<a class="facebook" onClick="window.open('http://www.facebook.com/sharer.php?u=<?php echo $this->item->url; ?>','Facebook','width=600,height=300,left='+(screen.availWidth/2-300)+',top='+(screen.availHeight/2-150)+''); return false;" href="http://www.facebook.com/sharer.php?u=<?php echo $this->item->url; ?>">
										<i class="fa fa-facebook"></i>
									</a>
							</li>
							<li>
									<a class="twitter" onClick="window.open('http://twitter.com/share?url=<?php echo $this->item->url; ?>&amp;text=<?php echo str_replace(" ", "%20", $displayData->title); ?>','Twitter share','width=600,height=300,left='+(screen.availWidth/2-300)+',top='+(screen.availHeight/2-150)+''); return false;" href="http://twitter.com/share?url=<?php echo $this->item->url; ?>&amp;text=<?php echo str_replace(" ", "%20", $displayData->title); ?>">
										<i class="fa fa-twitter"></i>
									</a>
							</li>
							<li>
									<a class="gplus" onClick="window.open('https://plus.google.com/share?url=<?php echo $this->item->url; ?>','Google plus','width=585,height=666,left='+(screen.availWidth/2-292)+',top='+(screen.availHeight/2-333)+''); return false;" href="https://plus.google.com/share?url=<?php echo $this->item->url; ?>" >
									<i class="fa fa-google-plus"></i></a>
							</li>

							<li>
									<a class="linkedin" onClick="window.open('http://www.linkedin.com/shareArticle?mini=true&url=<?php echo $this->item->url; ?>','Linkedin','width=585,height=666,left='+(screen.availWidth/2-292)+',top='+(screen.availHeight/2-333)+''); return false;" href="http://www.linkedin.com/shareArticle?mini=true&url=<?php echo $this->item->url; ?>" >
									<i class="fa fa-linkedin-square"></i></a>
							</li>
						</ul>
					</div>

				</div>
			</div>
			</div>
			<!-- /#col-sm-8 -->
		<div class="col-sm-4">
			<!-- Event Speakers -->
			<?php if(isset($this->item->speaker_infos) && $this->item->speaker_infos && count($this->item->speaker_infos)) {?>
				<div class="splms-event-speakers">
					<h3 class="splms-event-title"><?php echo JText::_('COM_SPLMS_EVENT_SPEAKER'); ?></h3>
					<div class="row">
					<?php
					$last_item = end($this->item->speaker_infos);
					foreach ($this->item->speaker_infos as $speaker_info) {
						?>
						<div class="splms-event-speaker splms-col-sm-6">
							<a href="<?php echo $speaker_info->url ?>" class="speaker-img">
								<img src="<?php echo $speaker_info->image; ?>" alt="<?php echo $speaker_info->title; ?>">
							</a>
							<h4 class="title">
								<a href="<?php echo $speaker_info->url ?>"><?php echo $speaker_info->title; ?></a>
							</h4>
							<p class="designation"><?php echo $speaker_info->designation; ?></p>
						</div>
					<?php } ?>
					</div> <!-- //.row -->
				</div>
			<?php } // has speaker ?>	
		</div>
		<!-- /#col-sm-4 -->
	</div>
	</div>


</div> <!-- /#splms -->
