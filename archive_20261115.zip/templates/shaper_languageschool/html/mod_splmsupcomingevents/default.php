<?php
/**
* @package com_splms
* @subpackage  mod_splmupcomingevents
*
* @author JoomShaper http://www.joomshaper.com
* @copyright Copyright (c) 2010 - 2018 JoomShaper
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
*/

// No Direct Access
defined ('_JEXEC') or die('Resticted Aceess');

// import component helper
jimport('joomla.application.component.helper');
jimport('joomla.filesystem.file');

// Get Thumb
$params = JComponentHelper::getParams('com_splms');
$thumb_size_small = strtolower($params->get('event_thumbnail_small', '100X60'));
$speaker_loaded = false;
?>

<div class="mod-splms-upcoming-events <?php echo $moduleclass_sfx; ?>">
	<?php if(count($items)){ ?>
		<ul class="splms-upcoming-events-lists">
			<?php foreach ($items as $key => $item) {?>
			<li class="splms-upcoming-event clearfix <?php echo ($key === 0 ? "first-item": " ");?>">
				<?php if($show_speakers && count($item->speakers) && !empty($item->speakers) ) { ?>
					<div class="splms-upcoming-event-info">
				<?php } ?>
				
					<?php
						$filename = basename($item->image);
						$path = JPATH_BASE .'/'. dirname($item->image) . '/thumbs/' . JFile::stripExt($filename) . '_' . $thumb_size_small . '.' . JFile::getExt($filename);
						$src = JURI::base(true) . '/' . dirname($item->image) . '/thumbs/' . JFile::stripExt($filename) . '_' . $thumb_size_small . '.' . JFile::getExt($filename);

						if(JFile::exists($path)) {
							$thumb = $src;
						} else {
							$thumb = $this->item->image;
						}
					?>

					<?php if($key === 0){?>
						<div class="splms-upcoming-event-date-wrap">
							<div class="splms-upcoming-event-date">
								<?php echo JHtml::_('date', $item->event_start_date, 'M'); ?>
								<span class="splms-upcoming-event-date-day">
									<?php echo JHtml::_('date', $item->event_start_date, 'd'); ?>
								</span>
							</div>
							<div class="splms-upcoming-event-price-wrap">
								<span class="splms-upcoming-event-time">
									<?php echo JHtml::_('date', $item->event_time, 'g:i a'); ?> - 
									<?php echo JHtml::_('date', $item->event_end_time, 'g:i a'); ?>
								</span>
								<span class="splms-upcoming-event-address">
									<?php echo $item->event_address;?>
								</span>
							</div>
						</div>
						<?php if ($item->price <= 0) {?>
							<p class="splms-upcoming-event-price"><?php echo JTEXT::_('MOD_SPLMS_EVENTS_FREE_SEMINARS');?></p>
							<?php } else {?>
								<div class="splms-upcoming-event-price">
									<?php echo JTEXT::_('MOD_SPLMS_EVENTS_PRICE'). ': ' . SplmsHelper::generateCurrency($item->price);?>
								</div>
						<?php }?>
					<?php } else{?>
						<small class="splms-upcoming-event-date">
							<?php echo JHtml::_('date', $item->event_start_date, 'DATE_FORMAT_LC3'); ?>
						</small>
					<?php }?>

					<strong class="splms-upcoming-event-title">
						<a href="<?php echo $item->url; ?>" class="splms-event-title"><?php echo $item->title; ?></a>
					</strong>
				<?php if($show_speakers && count($item->speakers) && !empty($item->speakers) ) { ?>
					</div>
				<?php } ?>
				<?php if($show_speakers && count($item->speakers) && !empty($item->speakers) ) { ?>
					<?php if($speaker_loaded != true) { ?>
						<div class="splms-upcoming-event-speakers-wrap">
							<?php foreach ($item->speakers as $speaker) { ?>
								<div class="splms-upcoming-event-speaker">
									<div class="splms-ue-speaker-media">
										<a href="<?php echo $speaker->url; ?>">
											<img src="<?php echo JURI::root() . $speaker->image; ?>" alt="<?php echo $speaker->title; ?>">
										</a>
									</div> <!-- /.splms-ue-speaker-media -->
									<div class="splms-ue-speaker-info">
										<p class="splms-ue-speaker-name">
											<a href="<?php echo $speaker->url; ?>">
												<?php echo $speaker->title; ?>
											</a>
											<small><?php echo $speaker->designation; ?></small>
										</p>
									</div> <!-- /.splms-ue-speaker-info -->
								</div> <!-- /.splms-upcoming-event-speaker -->
							<?php } ?>
						</div> <!-- /.splms-upcoming-event-speakers-wrap -->
					<?php } ?>
					<?php if($show_speakers == 'first') { $speaker_loaded = true; } ?>
				<?php } ?>
			</li>
			<?php } ?>
		</ul>
	<?php } else { ?>
		<p><?php echo JTEXT::_('COM_SPLMS_NO_ITEMS_FOUND');  ?></p>
	<?php } ?>
</div>
