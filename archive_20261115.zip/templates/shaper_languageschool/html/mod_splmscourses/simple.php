<?php
/**
* @package com_splms
* @subpackage  mod_splmscourses
*
* @author JoomShaper http://www.joomshaper.com
* @copyright Copyright (c) 2010 - 2018 JoomShaper
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
*/

// No Direct Access
defined ('_JEXEC') or die('Resticted Aceess');

jimport( 'joomla.filesystem.file' );

//Joomla Component Helper & Get LMS Params
jimport('joomla.application.component.helper');
$splmsparams = JComponentHelper::getParams('com_splms');

//Get Currency
$currency = explode(':', $splmsparams->get('currency', 'USD:$'));
$currency =  $currency[1];

// Get image thumb
$thumb_size = strtolower($splmsparams->get('course_thumbnail_small', '100X60'));

?>

<div class="mod-splms-courses splms simple-layout <?php echo $moduleclass_sfx; ?>">

	<div class="splms-courses-list">
		<?php foreach ($items as $item) { ?>
		<?php $item->price = ($item->price == 0) ? JText::_('MOD_SPLMS_COURSES_FREE') : SplmsHelper::generateCurrency($item->price, $item->sale_price); ?>
			<div class="mod-splms-course">
				<div class="splms-course-info-wrap">
					<p class="splms-course-duration"><?php echo $item->duration; ?></p>
					<h3 class="splms-course-title">
						<a href="<?php echo $item->url; ?>" class="splms-course-title"><?php echo $item->title; ?></a>
					</h3>
					<p class="splms-course-short-info"><?php echo $item->short_description; ?></p>
				</div>
			</div>
		<?php } ?>
	</div>
</div>

<?php
