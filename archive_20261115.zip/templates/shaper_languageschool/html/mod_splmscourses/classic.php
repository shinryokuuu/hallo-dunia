<?php
/**
* @package com_splms
* @subpackage  mod_splmscourses
*
* @author JoomShaper http://www.joomshaper.com
* @copyright Copyright (c) 2010 - 2018 JoomShaper
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
*/

// No Direct Access
defined ('_JEXEC') or die('Resticted Aceess');

jimport( 'joomla.filesystem.file' );

//Joomla Component Helper & Get LMS Params
jimport('joomla.application.component.helper');
$splmsparams = JComponentHelper::getParams('com_splms');

//Get Currency
$currency = explode(':', $splmsparams->get('currency', 'USD:$'));
$currency =  $currency[1];

// Get image thumb
$thumb_size = strtolower($splmsparams->get('course_thumbnail_small', '100X60'));

?>

<div class="mod-splms-courses splms classic-layout <?php echo $moduleclass_sfx; ?>">

	<div class="splms-courses-list splms-row">
		<?php foreach (array_chunk($items, $columns) as $items) { ?>
			<?php foreach ($items as $item) { ?>
			<?php $item->generated_price = ($item->price == 0) ? JText::_('MOD_SPLMS_COURSES_FREE') : SplmsHelper::generateCurrency($item->price, $item->sale_price);
				$discount_percentage = '';
				if( ($item->price > $item->sale_price) && ($item->sale_price != '0.00' && $item->price != '0.00') ) {
					$discount_percentage = (($item->price - $item->sale_price)*100) /$item->price;
				}

				// Get Prices
				if ($item->price == 0) {
					$item->course_price = JText::_('MOD_SPLMS_COURSES_FREE');
				}else{
					$item->course_price = SplmsHelper::generateCurrency($item->price, $item->sale_price);
				}
			?>
			<div class="splms-col-sm-<?php echo round(12 / $columns);?>">
				<div class="mod-splms-course">
					<div class="splms-course-img-wrap">
						<?php
						$filename = basename($item->image);
						$path = JPATH_BASE .'/'. dirname($item->image) . '/thumbs/' . JFile::stripExt($filename) . '_' . $thumb_size . '.' . JFile::getExt($filename);
						$src = JURI::base(true) . '/' . dirname($item->image) . '/thumbs/' . JFile::stripExt($filename) . '_' . $thumb_size . '.' . JFile::getExt($filename);

						if(JFile::exists($path)) {
							$thumb = $src;
						} else {
							$thumb = $item->image;	
						}
						?>
						<a href="<?php echo $item->url; ?>" class="splms-courses-img">
								<img src="<?php echo $thumb; ?>" class="splms-course-img splms-img-responsive" alt="<?php echo $item->title; ?>">
						</a>
						<a href="<?php echo $item->url; ?>" class="splms-courses-read-more"></a>
						<?php if (isset($discount_percentage) && $discount_percentage) {?>
							<span class="splms-course-discount-price"><?php echo round($discount_percentage) . JText::_('MOD_SPLMS_COURSES_PERCENT_OFF'); ?></span>
						<?php }?>
						
					</div>
					
					<div class="splms-course-info-wrap">
						<h3 class="splms-course-title">
							<a href="<?php echo $item->url; ?>" class="splms-course-title"><?php echo $item->title; ?></a>
						</h3>
						<p class="splms-course-short-info"><?php echo $item->short_description; ?></p>
						<p class="splms-course-duration"><?php echo $item->duration; ?></p>
						<p class="splms-course-time"><?php echo $item->level; ?></p>
						<p class="splms-course-price"><?php echo $item->course_price; ?></p>
					</div>
					
				</div>
				
			</div>
			<?php } ?>
		<?php } ?>
	</div>
</div>