/**
 * @package Helix Ultimate Framework
 * @author JoomShaper https://www.joomshaper.com
 * @copyright Copyright (c) 2010 - 2018 JoomShaper
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or Later
*/

jQuery(function ($) {

    // Stikcy Header
    if ($('body').hasClass('sticky-header')) {
        var header = $('#sp-header');

        if($('#sp-header').length) {
            var headerHeight = header.outerHeight();
            var stickyHeaderTop = header.offset().top;
            header.before('<div class="nav-placeholder"></div>');
            var stickyHeader = function () {
                var scrollTop = $(window).scrollTop();
                if (scrollTop > stickyHeaderTop) {
                    header.addClass('header-sticky');
                    $('.nav-placeholder').height(headerHeight);
                } else {
                    if (header.hasClass('header-sticky')) {
                        header.removeClass('header-sticky');
                        $('.nav-placeholder').height('inherit');
                    }
                }
            };
            stickyHeader();
            $(window).scroll(function () {
                stickyHeader();
            });
        }

        if ($('body').hasClass('layout-boxed')) {
            var windowWidth = header.parent().outerWidth();
            header.css({"max-width": windowWidth, "left": "auto"});
        }
    }

    // go to top
    $(window).scroll(function () {
        if ($(this).scrollTop() > 100) {
            $('.sp-scroll-up').fadeIn();
        } else {
            $('.sp-scroll-up').fadeOut(400);
        }
    });

    $('.sp-scroll-up').click(function () {
        $("html, body").animate({
            scrollTop: 0
        }, 600);
        return false;
    });

    // Preloader
    $(window).on('load', function () {
        $('.sp-preloader').fadeOut(500, function() {
            $(this).remove();
        });
    });

    //mega menu
    $('.sp-megamenu-wrapper').parent().parent().css('position', 'static').parent().css('position', 'relative');
    $('.sp-menu-full').each(function () {
        $(this).parent().addClass('menu-justify');
    });

    // Offcanvs
    $('#offcanvas-toggler').on('click', function (event) {
        event.preventDefault();
        $('.offcanvas-init').addClass('offcanvas-active');
    });

    $('.close-offcanvas, .offcanvas-overlay').on('click', function (event) {
        event.preventDefault();
        $('.offcanvas-init').removeClass('offcanvas-active');
    });
    
    $(document).on('click', '.offcanvas-inner .menu-toggler', function(event){
        event.preventDefault();
        $(this).closest('.menu-parent').toggleClass('menu-parent-open').find('>.menu-child').slideToggle(400);
    });

    //Tooltip
    $('[data-toggle="tooltip"]').tooltip();

    // Article Ajax voting
    $('.article-ratings .rating-star').on('click', function (event) {
        event.preventDefault();
        var $parent = $(this).closest('.article-ratings');

        var request = {
            'option': 'com_ajax',
            'template': template,
            'action': 'rating',
            'rating': $(this).data('number'),
            'article_id': $parent.data('id'),
            'format': 'json'
        };

        $.ajax({
            type: 'POST',
            data: request,
            beforeSend: function () {
                $parent.find('.fa-spinner').show();
            },
            success: function (response) {
                var data = $.parseJSON(response);
                $parent.find('.ratings-count').text(data.message);
                $parent.find('.fa-spinner').hide();

                if(data.status)
                {
                    $parent.find('.rating-symbol').html(data.ratings)
                }

                setTimeout(function(){
                    $parent.find('.ratings-count').text('(' + data.rating_count + ')')
                }, 3000);
            }
        });
    });

    //  Cookie consent
    $('.sp-cookie-allow').on('click', function(event) {
        event.preventDefault();
        
        var date = new Date();
        date.setTime(date.getTime() + (30 * 24 * 60 * 60 * 1000));
        var expires = "; expires=" + date.toGMTString();               
        document.cookie = "spcookie_status=ok" + expires + "; path=/";

        $(this).closest('.sp-cookie-consent').fadeOut();
    });

    //Template related JS
    $('.sppb-addon-articles .sppb-article-introtext').each(function(){
        let introText = $(this).find('p');
        $(this).html(introText);
    })

    if($('.main-login-page').length>0){
        $('input.validate-username').attr('placeholder', "Username")
        $('input.validate-password').attr('placeholder', "Password")
    }
    if ($('#member-registration').length>0){
        $('#jform_name').attr('placeholder', 'Full Name')
        $('#jform_username').attr('placeholder', 'Username')
        $('#jform_password1').attr('placeholder', 'Password')
        $('#jform_password2').attr('placeholder', 'Password Again')
        $('#jform_email1').attr('placeholder', 'Email')
        $('#jform_email2').attr('placeholder', 'Email Again')
    }
    if ($("ul.pagination").length>0){
        $('.page-link.previous').closest('.page-item').addClass('previous');
        $('.page-link.next').closest('.page-item').addClass('next');
        $('.page-link.first').closest('.page-item').addClass('first');
        $('.page-link.last').closest('.page-item').addClass('last');
    }
    // Select
    if ($(".my-select").length > 0) {
        $(document).on('click', function (e) {
            var selector = $('.my-select');
            if (!selector.is(e.target) && selector.has(e.target).length === 0) {
                selector.find('ul').slideUp();
            }
        });

        $('select.my-select').each(function (event) {
            $(this).hide();
            var $self = $(this);
            var spselect = '<div class="my-select">';
            spselect += '<div class="my-select-result">';
            spselect += '<span class="my-select-text">' + $self.find('option:selected').text() + '</span>';
            spselect += ' <i class="fa fa-caret-down"></i>';
            spselect += '</div>';
            spselect += '<ul class="my-select-dropdown">';

            $self.children().each(function (event) {
                if ($self.val() == $(this).val()) {
                    spselect += '<li class="active" data-val="' + $(this).val() + '">' + $(this).text() + '</li>';
                } else {
                    spselect += '<li data-val="' + $(this).val() + '">' + $(this).text() + '</li>';
                }
            });

            spselect += '</ul>';
            spselect += '</div>';
            $(this).after($(spselect));
        });

        $(document).on('click', '.my-select', function (event) {
            $('.my-select').not(this).find('ul').slideUp();
            $(this).find('ul').slideToggle();
        });

        $(document).on('click', '.my-select ul li', function (event) {
            var $select = $(this).closest('.my-select').prev('select');
            $(this).parent().prev('.my-select-result').find('span').html($(this).text());
            $(this).parent().find('.active').removeClass('active');
            $(this).addClass('active');
            $select.val($(this).data('val'));
            $select.change();
        });
    }
    // End Select
});
