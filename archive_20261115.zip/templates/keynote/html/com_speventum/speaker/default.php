<?php
/**
 * @package     SP Eventum
 *
 * @copyright   Copyright (C) 2010 - 2020 JoomShaper. All rights reserved.
 * @license     GNU General Public License version 2 or later.
 */

defined('_JEXEC') or die();

?>

<div id="sp-com-eventum" class="sp-com-eventum sp-eventum-view-speaker">
	<div class="row">
		<div class="col-lg-3 col-4">
			<img src="<?php echo $this->speaker->image; ?>" alt="<?php echo $this->speaker->title; ?>">
		</div>

		<div class="col-lg-9 col-8">

			<h2 class="speaker-title"><?php echo $this->speaker->title; ?></h2>
			<p class="lead speaker-designation"><?php echo $this->speaker->designation; ?></p>

			<?php if(isset($this->speaker->url) && $this->speaker->url) { ?>
			<p class="speaker-website"><a target="_blank" href="<?php echo $this->speaker->url; ?>"><?php echo $this->speaker->url; ?></a></p>
			<?php } ?>

			<?php if(count($this->speaker->socials)) { ?>
			<div class="speaker-social-icons">
				<ul>
				<?php foreach ($this->speaker->socials as $key => $social) { ?>
					<li>
						<a target="_blank" class="social-<?php echo $social[0]; ?>" href="<?php echo $social[1]; ?>"><i class="fa fa-<?php echo $social[0]; ?>"></i></a>
					</li>
				<?php } ?>
				</ul>
			</div>
			<?php } ?>

			<div class="speaker-description">
				<?php echo $this->speaker->description; ?>
			</div>
			
			<?php if (!empty($this->sessions)) { ?>
				<div class="speaker-sessions">
					<h4><?php echo JText::_('COM_SPEVENTUM_SPEAKER_SESSIONS'); ?></h4>
					<?php foreach ($this->sessions as $session) { ?>
						<div class="session-wrapper">
							<h5 class="session-title">
								<?php echo $session->title; ?>
								<small class="text-mute"><?php echo '(' . $session->opening . ' - ' . $session->closing . ')'; ?></small>
							</h5>
						</div>
					<?php } ?>
				</div>
			<?php } ?>
		</div>
	</div>
</div>