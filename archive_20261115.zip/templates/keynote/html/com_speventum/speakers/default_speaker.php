<?php
/**
 * @package     SP Eventum
 *
 * @copyright   Copyright (C) 2010 - 2020 JoomShaper. All rights reserved.
 * @license     GNU General Public License version 2 or later.
 */

defined('_JEXEC') or die();

$sessions = $this->model->getSessionsForSpeaker($this->speaker->speventum_speaker_id);

?>
<div class="sp-speaker">
	<div class="speaker-image">
	<?php
		$socials = array();

		if(isset($this->speaker->social_twitter) && $this->speaker->social_twitter) {
			$socials[] = array('twitter', 'https://twitter.com/' . $this->speaker->social_twitter);
		}

		if(isset($this->speaker->social_facebook) && $this->speaker->social_facebook) {
			$socials[] = array('facebook', 'https://www.facebook.com/' . $this->speaker->social_facebook);
		}

		if(isset($this->speaker->social_googleplus) && $this->speaker->social_googleplus) {
			$socials[] = array('google-plus', 'https://plus.google.com/' . $this->speaker->social_googleplus);
		}

		if(isset($this->speaker->social_pinterest) && $this->speaker->social_pinterest) {
			$socials[] = array('pinterest', 'https://www.pinterest.com/' . $this->speaker->social_pinterest);
		}

		if(isset($this->speaker->social_linkedin) && $this->speaker->social_linkedin) {
			$socials[] = array('linkedin', $this->speaker->social_linkedin);
		}

		if(isset($this->speaker->social_dribbble) && $this->speaker->social_dribbble) {
			$socials[] = array('dribbble', 'https://dribbble.com/' . $this->speaker->social_dribbble);
		}

		if(isset($this->speaker->social_behance) && $this->speaker->social_behance) {
			$socials[] = array('behance', 'https://www.behance.net/' . $this->speaker->social_behance);
		}

		if(isset($this->speaker->social_flickr) && $this->speaker->social_flickr) {
			$socials[] = array('flickr', 'https://www.flickr.com/people/' . $this->speaker->social_flickr);
		}

		if(isset($this->speaker->social_youtube) && $this->speaker->social_youtube) {
			$socials[] = array('youtube', 'https://www.youtube.com/user/' . $this->speaker->social_youtube);
		}

		if(isset($this->speaker->social_vimeo) && $this->speaker->social_vimeo) {
			$socials[] = array('vimeo', 'https://vimeo.com/' . $this->speaker->social_vimeo);
		}

		if(isset($this->speaker->social_github) && $this->speaker->social_github) {
			$socials[] = array('github', 'https://github.com/' . $this->speaker->social_github);
		}

		if(isset($this->speaker->social_skype) && $this->speaker->social_skype) {
			$socials[] = array('skype', 'skype:' . $this->speaker->social_skype . '?chat');
		}

		// Limit social icons
		if(count($socials)>4) {
			$socials = array_slice($socials, 0, 4);
		}

		?>

		<div class="speaker-image-wrapper">
			<img src="<?php echo $this->speaker->image; ?>" alt="<?php echo $this->speaker->title; ?>">
			<?php if(!empty($socials)) { ?>
			<div class="social-icons">
				<ul class="social-links-<?php echo count($socials); ?>">
				<?php foreach ($socials as $key => $social) { ?>
					<li class="social-<?php echo $key+1; ?>">
						<a target="_blank" class="social-<?php echo $social[0]; ?>" href="<?php echo $social[1]; ?>"><i class="fa fa-<?php echo $social[0]; ?>"></i></a>
					</li>
				<?php } ?>
				</ul>
			</div>
			<?php } ?>
			
			<?php if (!empty($sessions)) { ?>
				<div class="speaker-session-wrapper">
					<p class="speaker-session-topic"><?php echo JText::_('COM_SPEVENTUM_LABEL_TOPIC') ?></p>
					<h5 class="speaker-session-title"><?php echo $sessions[0]->title; ?></h5>
				</div>
			<?php } ?>
		</div>
	</div>
	<h4 class="speaker-title"><a href="<?php echo JRoute::_('index.php?option=com_speventum&view=speaker&id=' . $this->speaker->speventum_speaker_id . ':' . $this->speaker->slug . EventumHelper::getItemid('com_speventum&view=speakers')); ?>"><?php echo $this->speaker->title; ?></a></h4>
	<p class="speaker-designation"><?php echo $this->speaker->designation; ?></p>
</div>